<?php

namespace App\Providers;

use App\Listeners\LogSentEmail;
use App\Models\EventUser;
use App\Models\Payment;
use App\Models\PaymentInvoice;
use App\Observers\EventUserObserver;
use App\Observers\PaymentInvoiceObserver;
use App\Observers\PaymentObserver;
use Illuminate\Mail\Events\MessageSent;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\URL;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */

    public function register(): void
    {
        Blade::directive('money', function ($amount) {
            return "<?php echo 'Rp ' . number_format($amount, 0, ',', '.'); ?>";
        });

        Gate::before(function ($user, $ability) {
            return $user->hasRole('super-admin') ? true : null;
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Payment::observe(PaymentObserver::class);
        EventUser::observe(EventUserObserver::class);
        PaymentInvoice::observe(PaymentInvoiceObserver::class);

        if (app()->environment('production')) {
            URL::forceScheme('https');
        }
        Http::globalOptions([
            'timeout' => 180000,
        ]);
    }
}
