<!--begin::Statistics Widget 5-->
<a href="#" class="card bg-gray-900 hoverable card-xl-stretch mb-5 mb-xl-8">
    <!--begin::Body-->
    <div class="card-body">
        <i class="ki-duotone ki-chart-simple text-gray-100 fs-2x ms-n1"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></i>
        <div class="text-gray-100 fw-bold fs-2 mb-2 mt-5">
            Sales Stats
        </div>
        <div class="fw-semibold text-gray-100">
           50% Increased for FY20        </div>
    </div>
    <!--end::Body-->
</a>
<!--end::Statistics Widget 5-->
