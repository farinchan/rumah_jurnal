<!--begin::Drawers-->
@include("back/partials/drawers/_activity-drawer")
@include("back/partials/drawers/_chat-messenger")
@include("back/partials/drawers/_shopping-cart")
<!--end::Drawers-->
